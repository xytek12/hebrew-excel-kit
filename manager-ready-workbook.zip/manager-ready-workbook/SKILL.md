---
name: manager-ready-workbook
description: Audit a messy or unpolished Excel workbook and turn it into a manager/CTO-ready model — interviews the user first (8+ questions), then fixes formulas, layout, RTL, dashboard, inventory analytics and formatting without breaking anything.
---

# Manager-Ready Workbook

Turn a workbook into something an executive can open and understand in ten seconds — correct formulas, one visual language, no horizontal scrolling, a real dashboard, and no filler text.

## When to use

- "check all the data and make it better / more understandable for managers"
- "the dashboard sucks, make it pro for my CTO"
- "fix the tables, I have to scroll left and right"
- "I have a messy raw file and a clean formatted file — move the data over without breaking the good one"
- Any request to audit, clean, restructure or beautify an existing workbook

Do NOT use for building a new model from scratch with no existing file, or for single-cell edits.

---

## Step 1 — Analyse before saying anything

Read the workbook first. Never ask questions blind and never write yet.

1. Enumerate sheets from the workbook's own collection: name, position, tab colour, used range, row/col count.
2. For each sheet read **values AND formulas** (`get_cell_ranges`), plus:
   - Tables (`sheet.tables`) — names, ranges, styles, and any **saved AutoFilter criteria**
   - Charts — titles, series count, source ranges, position
   - Pivot tables (`sheet.pivotTables`) — layout type, grand totals
   - Data validation on any input-looking cell
   - Freeze panes via `freezePanes.getLocationOrNullObject()` (`isNullObject` = none; there is no `frozenRows` property)
   - Hidden rows/columns, and whether they are hidden or *grouped*
3. Render 2–3 key sheets as images (`getImage()` + `attachImage`) — layout problems are invisible in cell values. Keep ranges under ~50 rows.
4. Sweep every used range for `#REF!/#NAME?/#VALUE!/#DIV/0!`.
5. Look for **silent** defects, not just error values:
   - a formula that identifies a row by one column but reports a value from `MIN`/`MAX` of another (classic wrong-row bug)
   - assumption cells that nothing references (dead parameters)
   - hardcoded font colours doing the job of conditional formatting
   - saved filters hiding rows so totals and the visible list disagree
   - `@`-prefixed or `XLOOKUP` formulas that return `#NAME?` on older Excel
   - a cash-flow that collects revenue in-month and never remits VAT

**Done when:** you can name every sheet's purpose, every table, and at least three specific defects with cell addresses.

---

## Step 2 — Interview the user (minimum 8 questions)

Ask **before** writing anything. Use `ask_user_question` in batches of up to 4, at most 4 questions per call, so keep going until you have asked at least 8. Ground every question in what you actually found — quote real sheet names, cell addresses and numbers.

Cover these areas:

1. **Audience** — who opens this file (CTO / CFO / store managers / board)? Drives density and language.
2. **Scope** — polish the existing structure, or restructure/rebuild layout?
3. **Language & direction** — confirm RTL/LTR and the content language. Never change it.
4. **Units & precision** — whole currency, thousands, or decimals? Symbol in cells or stated once in the title?
5. **Correctness calls** — for each modelling flaw found, offer concrete options. Example: "the cash flow ignores the 45/60 credit-day assumptions and never remits VAT; year-end cash would drop from X to Y — fix it fully, or leave it and just document?"
6. **Which numbers are the headline KPIs** — list the candidates you found and let them pick.
7. **What decisions they want the file to drive** — reorder stock? shift inventory between branches? cut cost?
8. **Charts** — which trends matter, and inline on the dashboard or on a separate tab?
9. **Inputs vs outputs** — which cells are theirs to edit, so you can colour-code them.
10. **What must not change** — protected numbers, external links, existing tab names.

If two workbooks are open, also ask:

11. **Which file is the source of truth** and which is the formatted target?
12. **Append or replace** the target's data, and does row count grow over time?
13. **Key columns** for matching (for XLOOKUP/INDEX-MATCH joins).

**Done when:** you have 8+ answers, or the user says "just do it" — in which case state your assumptions explicitly in chat before writing.

---

## Step 3 — Plan in chat, then stop

Present numbered phases with the sheets and ranges each will touch. End your turn and wait. Do not start writing on the same turn as the plan.

**Done when:** the user has confirmed or adjusted.

---

## Step 4 — Two-workbook mode (raw → formatted)

Only if the user confirmed a second file.

- The formatted target is **sacred**. Never overwrite its formula columns, tables, pivots or charts.
- Write raw data **only** into the target's designated input area or a new data sheet.
- Join with `XLOOKUP` (or `INDEX/MATCH` if any doubt about Excel version) on the confirmed key columns.
- If the target has real Excel Tables, use structured references (`Table[Column]`, `[@Column]`) so new rows are picked up automatically.
- After landing data, refresh pivots and re-read every formula column for errors.
- Report row counts in vs out and any unmatched keys.

**Done when:** target row count and totals tie to the source, and no formula column contains an error.

---

## Step 5 — Fix pass

Work in small `set_cell_range` / `execute_office_js` calls, one logical section each, so the user sees progress.

### Formulas
- Rewrite `#NAME?` lookups as `INDEX/MATCH`.
- Move every business assumption into a labelled cell; formulas reference it.
- Wire up dead parameters or delete them — never leave an assumption nothing uses.
- Split unreadable nested formulas into labelled helper steps.
- Make patterns draggable: put the varying literal (month, region) in a header cell and reference it, then `copy_paste_range` / `autoFill`.

### Layout — the no-scroll budget
`format.columnWidth` is in **points**; multiply by ~1.33 for pixels. Keep a sheet's visible columns to **≤ ~850 pt total**. Observed: 1,100 pt overflows a normal window and Excel parks at the far end, hiding column A (which in RTL is the *first* column the user looks for).
- 13-month grid that fits: label 135 pt, months 52 pt, annual total 64 pt, grid font 9.5 pt.
- Drop the currency symbol from grid cells and state it once in the title — that alone buys ~20 pt per column.
- Uniform month widths. Use merged cells (e.g. `D:F`) for a wide explanation column so the grid below it stays even.
- After resizing, `sheet.getRange("A1").select()` to reset the scroll position.

### Formatting — one spec for the whole workbook
Decide once, apply everywhere. Suggested palette: navy `#1F3A5C`, band `#F7F9FC`, header accent `#E8EDF4`, rule `#D8DEE8`, ink `#1A1A1A`.
- Currency `#,##0;[Red](#,##0);-` · percent `0.0%;[Red](0.0%);-` · unit prices 2 dp · dates local order (`dd/mm/yyyy` for he-IL)
- Blue `#0000FF` = editable input, black = formula. Add a small legend on the assumptions sheet.
- Replace hardcoded status font colours with **conditional formatting** so it follows the data.
- Header rows: navy fill, white bold, centred, wrapped, row height ~30–40.

### Cleanliness
- Delete AI-ish explainer subtitles ("each row = one item…", "all numbers update automatically…"). Keep the title; make row 2 a thin rule.
- **Never clear a whole row or column across all sheets.** Dropdown source lists and helper data hide in odd cells; clearing `A2:N2` workbook-wide will silently destroy list entries. Read the range first, or clear only the specific cells.
- Clear saved AutoFilters that hide rows.
- **Group** helper columns behind a `+` toggle — never hide them. Collapse with `sheet.showOutlineLevels(1, 1)`.
- Tabs: order dashboard → lookup → statements → data → inputs, and colour by group (navy / blue / green / amber). Remove Latin words from Hebrew tab names.

### Dashboard
- Single column band ~840 pt wide so nothing sits off-screen. Set pair widths so each card spans two columns of equal total.
- 8 KPI cards in a 4×2 grid: label (9.5 pt grey) / value (18 pt bold) / sub-note (8.5 pt grey), merged across the pair, light fill, thin border, **thick top border accent coloured by meaning** — navy performance, green cash, amber stuck money, red alerts.
- Then data-driven insight lines (formulas building sentences, not typed text), then the action/alert table, then charts.
- Anchor charts to cells with `setPosition("A37","D54")` **below** the content. Never leave them floating beside it.

### Charts — the gotchas
- After `charts.add()`, `context.sync()` **before** touching `series.getItemAt(0)`.
- Line series: set `format.line.color`; `format.fill.setSolidColor` throws.
- `smooth` is invalid on bar/column series.
- If the chart's source columns sit in a **collapsed group they plot as blank** — set `chart.plotVisibleOnly = false`.
- Legend off for single-series. Label both axes, `numberFormat = "#,##0"`, gridlines in the light rule colour, data labels on bar charts.
- Non-contiguous source (labels in a row, values in another) → build a small 2-column source block via `INDEX(...,ROW()-n)` in a grouped helper area.

### Pivots
- `pivotLayout.layoutType = "Tabular"` replaces the English "Row Labels"/"Column Labels" with real field names.
- "Grand Total" cannot be renamed via the API. Turn off `showRowGrandTotals` / `showColumnGrandTotals` and write your own total row/column in the user's language.

### Tables
- A Table's calculated-column autofill **will overwrite your per-row formulas** with the first data row's pattern. Write each column as one whole-range array, or `convertToRange()` for a fixed-size grid (a 12-month block never grows).
- Keep tables for genuinely growing logs.

### Dropdowns
- Show human-readable names, not codes. If names collide, disambiguate (`name · size`).
- Point the validation `list.source` at a helper column of display names, then resolve back to the key with `INDEX(keys, MATCH(display, names, 0))` in a labelled cell, and have every downstream lookup use that resolved cell.

---

## Step 6 — Actionable analytics (do this, it's the differentiator)

Managers want an instruction, not a table. Build a small per-entity reference block in a grouped helper area, then surface one sentence.

Pattern used for cross-store inventory rebalancing:
1. Match keys inside the data table: `=SKU&"|"&weeksCover`, `=SKU&"|"&monthlySales`.
2. One row per SKU: top-selling branch = `INDEX(store, MATCH(sku&"|"&SUMPRODUCT(MAX((skuCol=sku)*salesCol)), salesKey, 0))`; deepest-surplus branch the same way on cover; spare units = `MAX(0, ROUND(stock - sales/4.33*minWeeks, 0))`.
   (`SUMPRODUCT(MAX(...))` works on every Excel version — prefer it to `MAXIFS`.)
3. Output one sentence: *"Move 196 units from Branch A to Branch B"*, with a clean fallback when there is no surplus anywhere ("no surplus in the network — order from the supplier").
4. Surface the same source on the dashboard alert table as a "transfer from" column.

**Done when:** every entity in the dropdown produces a correct recommendation or a correct "nothing available" message — test them all in a loop.

---

## Step 7 — Verify, then report

1. Sweep every sheet's used range for error values. Zero, or name them.
2. Tie-outs: dashboard KPIs vs source sheets, pivot totals vs summary tables, statement totals vs detail.
3. Exercise interactive elements — loop through every dropdown value and check the outputs.
4. Confirm structural state by **direct read**: freeze panes, `columnHidden`, validation `rule`, table filters.
5. Render each changed sheet as an image and actually look at it — clipped text, uneven grids, blank charts, wrong text direction.
6. Re-read displayed **text** (not just values) for anything formatting-related.

Report: what you did and where, which ranges you re-read, and **which you did not**. Never say "all" unless you checked all. Name anything that failed or that you deliberately left alone.
